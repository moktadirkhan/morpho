package com.syscom.MorphoSmartLite;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class xml {
        public static final int device_filter = 0x7f060000;
    }
}
