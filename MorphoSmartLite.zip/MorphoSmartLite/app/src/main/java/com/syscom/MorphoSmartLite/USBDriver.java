package com.syscom.MorphoSmartLite;

import android.content.Context;

import java.io.IOException;
/* loaded from: classes.dex */
interface USBDriver {
    public static final int DEFAULT_TIMEOUT = 0;

    byte[] instantReceive(Context context) throws IOException, IllegalArgumentException;

    byte[] receive(Context context) throws IOException, IllegalArgumentException;

    void send(byte[] bArr, Context context, Callback callback) throws IOException, IllegalArgumentException;
}
