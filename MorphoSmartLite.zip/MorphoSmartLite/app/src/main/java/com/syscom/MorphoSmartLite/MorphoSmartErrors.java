package com.syscom.MorphoSmartLite;
/* loaded from: classes.dex */
public interface MorphoSmartErrors {

    /* loaded from: classes.dex */
    public enum Errors {
        USB_PERMISSION_REQUIRED,
        PERMISSION_DENIED,
        COMMUNICATION_ERROR,
        INVALID_KEY,
        KEY_NOT_FOUND,
        INVALID_TIMEOUT,
        REQUEST_TIMED_OUT,
        COMMAND_ABORTED,
        SECURITY_ERROR,
        BAD_PARAMETER,
        BAD_SIGNATURE,
        SECU_CERTIFICATE_NOT_EXIST,
        ERROR,
        KCV_FAILURE,
        TEMPLATE_DECRYPTION_FAILED
    }

    /* loaded from: classes.dex */
    public enum Messages {
        MOVE_NO_FINGER,
        MOVE_FINGER_UP,
        MOVE_FINGER_DOWN,
        MOVE_FINGER_LEFT,
        MOVE_FINGER_RIGHT,
        PRESS_FINGER_HARDER,
        LATENT,
        REMOVE_FINGER,
        FINGER_OK,
        FINGER_DETECTED,
        FINGER_MISPLACED,
        LIVE_OK
    }

    /* loaded from: classes.dex */
    public enum Response {
        DEVICE_REGISTERED,
        PERMISSION_GRANTED,
        REGISTERED,
        NOT_REGISTERED,
        DEVICE_UNREGISTERED
    }
}
