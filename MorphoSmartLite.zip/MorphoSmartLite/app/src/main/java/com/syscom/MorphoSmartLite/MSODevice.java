
package com.syscom.MorphoSmartLite;

import android.content.Context;
import android.util.Log;

import com.syscom.MorphoSmartLite.MorphoSmartErrors.Errors;
import com.syscom.MorphoSmartLite.MorphoSmartErrors.Response;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class MSODevice {
    private static final int MAX_TIMEOUT_SECONDS = 42948;
    private static MSODevice mMSOInstance;
    private final USBHandler mUSBHandler = new USBHandler();
    private byte[] decryptionKeyBytes;

    private MSODevice() {
    }

    public String sdkVersion() {
        return "Version code: 2\nVersion name: 1.1";
    }

    public static final synchronized MSODevice getInstance() {
        Class var0 = MSODevice.class;
        synchronized(MSODevice.class) {
            return mMSOInstance == null ? (mMSOInstance = new MSODevice()) : mMSOInstance;
        }
    }

    public static final synchronized MSODevice getInstance(byte[] decryptionKey) {
        Class var1 = MSODevice.class;
        synchronized(MSODevice.class) {
            if (mMSOInstance == null) {
                mMSOInstance = new MSODevice();
                mMSOInstance.decryptionKeyBytes = decryptionKey;
                return mMSOInstance;
            } else {
                return mMSOInstance;
            }
        }
    }

    public synchronized void requestPermission(Callback callback, Context context) throws IOException {
        this.mUSBHandler.initiate(callback, context);
    }

    public String getDeviceSerialNumber(Callback callback, Context context) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            this.mUSBHandler.getDeviceSN(callback, context);
            return this.mUSBHandler.deviceSerialNumber;
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
            return null;
        }
    }

    public String getDeviceModel(Callback callback, Context context) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            this.mUSBHandler.getDeviceMN(callback, context);
            return this.mUSBHandler.deviceModel;
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
            return null;
        }
    }

    public synchronized void isRegistered(Callback callback, Context context) throws IOException, UnsupportedOperationException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            String deviceKCV = this.getDeviceKCV(callback, context);
            if (deviceKCV == null) {
                throw new UnsupportedOperationException("Operation not supported");
            }

            if (this.getDecryptionKeyKCV(callback).equalsIgnoreCase(deviceKCV)) {
                callback.onRegistered(Response.REGISTERED);
            } else {
                callback.onRegistered(Response.NOT_REGISTERED);
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
        }

    }

    private String getDecryptionKeyKCV(Callback callback) {
        String cipher = null;

        try {
            cipher = Utility.byteArrayToHexString(Utility.encrypt(Utility.hexStringToByteArray("00000000000000000000000000000000"), this.decryptionKeyBytes));
        } catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException | BadPaddingException | InvalidKeyException | IllegalBlockSizeException | NoSuchPaddingException var4) {
            callback.onFailure(Errors.KCV_FAILURE);
        }

        if (cipher != null) {
            cipher = cipher.substring(0, 6);
        } else {
            callback.onFailure(Errors.KCV_FAILURE);
        }

        return cipher;
    }

    private String getDeviceKCV(Callback callback, Context context) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            this.mUSBHandler.send(Utility.hexStringToByteArray("53594E4304000000FBFFFFFFC6010002454E"), context, callback);
            byte[] response = this.mUSBHandler.instantReceive(context);
            if (response != null) {
                String responseString = Utility.byteArrayToHexString(response);
                if (responseString.substring(24, 26).equalsIgnoreCase("c6") && responseString.substring(30, 32).equalsIgnoreCase("00")) {
                    String kcv = responseString.substring(32, 38);
                    return kcv;
                } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("B8")) {
                    callback.onFailure(Errors.KEY_NOT_FOUND);
                    return null;
                } else {
                    callback.onFailure(Errors.COMMUNICATION_ERROR);
                    return null;
                }
            } else {
                callback.onFailure(Errors.COMMUNICATION_ERROR);
                return null;
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
            return null;
        }
    }

    public synchronized void unRegsiter(Callback callback, Context context, byte[] lockPayload) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            if (this.mUSBHandler.getDeviceType() == 1) {
                String ILVunlock = this.getLoadKsSymmetric(lockPayload);
                this.mUSBHandler.send(Utility.hexStringToByteArray(ILVunlock), context, callback);
                byte[] response = this.mUSBHandler.instantReceive(context);
                if (response != null) {
                    if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("00")) {
                        callback.onLocked(Response.DEVICE_UNREGISTERED);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("FF")) {
                        callback.onFailure(Errors.ERROR);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("FE")) {
                        callback.onFailure(Errors.BAD_PARAMETER);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("DE")) {
                        callback.onFailure(Errors.SECURITY_ERROR);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("F0")) {
                        callback.onFailure(Errors.BAD_SIGNATURE);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("E2")) {
                        callback.onFailure(Errors.SECU_CERTIFICATE_NOT_EXIST);
                    }
                } else {
                    callback.onFailure(Errors.COMMUNICATION_ERROR);
                }
            } else if (this.mUSBHandler.getDeviceType() == 2 || this.mUSBHandler.getDeviceType() == 0) {
                callback.onFailure(Errors.KEY_NOT_FOUND);
                throw new UnsupportedOperationException("Operation not supported");
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
        }

    }

    public synchronized void register(Callback callback, Context context, byte[] unlockPayload) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            if (this.mUSBHandler.getDeviceType() == 1) {
                String ILVunlock = this.getLoadKsSymmetric(unlockPayload);
                this.mUSBHandler.send(Utility.hexStringToByteArray(ILVunlock), context, callback);
                byte[] response = this.mUSBHandler.instantReceive(context);
                if (response != null) {
                    if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("00")) {
                        callback.onUnlocked(Response.DEVICE_REGISTERED);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("FF")) {
                        callback.onFailure(Errors.ERROR);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("FE")) {
                        callback.onFailure(Errors.BAD_PARAMETER);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("DE")) {
                        callback.onFailure(Errors.SECURITY_ERROR);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("F0")) {
                        callback.onFailure(Errors.BAD_SIGNATURE);
                    } else if (Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("E2")) {
                        callback.onFailure(Errors.SECU_CERTIFICATE_NOT_EXIST);
                    }
                } else {
                    callback.onFailure(Errors.COMMUNICATION_ERROR);
                }
            } else if (this.mUSBHandler.getDeviceType() == 2 || this.mUSBHandler.getDeviceType() == 0) {
                callback.onFailure(Errors.KEY_NOT_FOUND);
                throw new UnsupportedOperationException("Operation not supported");
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
        }

    }

    public void capture(Callback callback, Context context) throws IOException {
        this.capture(0, callback, context);
    }

    public synchronized void capture(int timeoutInSeconds, Callback callback, Context context) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            if (timeoutInSeconds <= 42948) {
                String ILVWithTimeout;
                byte[] response;
                if (this.mUSBHandler.getDeviceType() == 1) {
                    ILVWithTimeout = this.getEnrollILVWithTimeout(timeoutInSeconds, "53594E433E000000C1FFFFFF213B000000000001010001040200310014010000140100003801006E44040012000000A701000034040041000000A5010001A6010000AE010000AF010000454E");
                    Log.i("MSO", "capture: " + Utility.hexStringToByteArray(ILVWithTimeout));
                    callback.onResponse(Utility.hexStringToByteArray(ILVWithTimeout));
                    this.mUSBHandler.send(Utility.hexStringToByteArray(ILVWithTimeout), context, callback);
                    response = this.mUSBHandler.receive(context);
                    if (response != null) {

                        int secondHalfSize = response.length % 8;

                        int firstHalfEnd = response.length - secondHalfSize;
                        byte[] paddedBytes = Arrays.copyOf(response, firstHalfEnd);
                        byte[] slice = Arrays.copyOfRange(response, firstHalfEnd, firstHalfEnd + secondHalfSize);
                        if (this.decryptionKeyBytes != null) {
                            byte[] decryptedTemplateData = null;

                            try {
                                decryptedTemplateData = Utility.decryptTemplate(paddedBytes, this.decryptionKeyBytes);


                            } catch (NoSuchAlgorithmException | InvalidKeyException | InvalidAlgorithmParameterException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException var12) {
                                callback.onFailure(Errors.TEMPLATE_DECRYPTION_FAILED);
                            }

                            byte[] decryptedTemplateWithExtraPadding = new byte[decryptedTemplateData.length + slice.length];
                            System.arraycopy(decryptedTemplateData, 0, decryptedTemplateWithExtraPadding, 0, decryptedTemplateData.length);
                            System.arraycopy(slice, 0, decryptedTemplateWithExtraPadding, decryptedTemplateData.length, slice.length);
                            callback.onResponse(response);

                        } else {
                            callback.onFailure(Errors.INVALID_KEY);
                        }
                    } else if (!this.mUSBHandler.isCancelled && !this.mUSBHandler.isTimeout) {
                        callback.onFailure(Errors.COMMUNICATION_ERROR);
                    }
                } else if (this.mUSBHandler.getDeviceType() == 2) {
                    ILVWithTimeout = this.getEnrollILVWithTimeout(timeoutInSeconds, "53594E433A000000C5FFFFFF2137000000000001010001040200310014010000140100003801006E4404001200000034040041000000A5010001A6010000AE010000AF010000454E");
                    this.mUSBHandler.send(Utility.hexStringToByteArray(ILVWithTimeout), context, callback);
                    response = this.mUSBHandler.receive(context);
                    if (response != null) {
                        callback.onResponse(response);
                    } else if (!this.mUSBHandler.isCancelled && !this.mUSBHandler.isTimeout) {
                        callback.onFailure(Errors.COMMUNICATION_ERROR);
                    }
                } else if (this.mUSBHandler.getDeviceType() == 0) {
                    callback.onFailure(Errors.COMMUNICATION_ERROR);
                }
            } else {
                callback.onFailure(Errors.INVALID_TIMEOUT);
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
        }

    }

    public void cancelLiveAcquisition(Callback callback, Context context) throws IOException {
        if (this.mUSBHandler.isPermissionObtained(callback, context)) {
            if (!this.mUSBHandler.isCancelled) {
                this.mUSBHandler.send(Utility.hexStringToByteArray("53594E4303000000FCFFFFFF700000454E"), context, callback);
                byte[] response = this.mUSBHandler.instantReceive(context);
                if (response != null && Utility.byteArrayToHexString(response).substring(30, 32).equalsIgnoreCase("E5")) {
                    callback.onCancelled(Errors.COMMAND_ABORTED);
                }
            }
        } else {
            this.mUSBHandler.setDeviceType(0);
            callback.onPermissionRequired(Errors.USB_PERMISSION_REQUIRED);
            this.requestPermission(callback, context);
        }

    }

    private String getEnrollILVWithTimeout(int timeout, String ILV) {
        byte[] timeoutBytes = Utility.intToByteArray(timeout);
        String timeoutHexString = Utility.byteArrayToHexString(timeoutBytes);
        String timeoutString = Utility.swapEndianness(timeoutHexString.substring(4, 8));
        StringBuilder stringBuffer = new StringBuilder(ILV);
        StringBuilder ILVWithTimeout = stringBuffer.replace(32, 36, timeoutString);
        return ILVWithTimeout.toString();
    }

    private String getLoadKsSymmetric(byte[] unlockPayload) {
        String finalPayload = "C7" + Utility.swapEndianness(String.format("%04X", Utility.byteArrayToHexString(unlockPayload).length() / 2 + 1)) + "02" + Utility.byteArrayToHexString(unlockPayload);
        finalPayload = "53594E43" + Utility.swapEndianness(String.format("%08X", finalPayload.length() / 2)) + Utility.swapEndianness(Utility.onesComplement(String.format("%08X", finalPayload.length() / 2))) + finalPayload + "454E";
        return finalPayload;
    }
}
