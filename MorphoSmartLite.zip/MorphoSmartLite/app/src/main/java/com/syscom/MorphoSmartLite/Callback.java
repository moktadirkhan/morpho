package com.syscom.MorphoSmartLite;

/* loaded from: classes.dex */
public interface Callback {
    void onCancelled(MorphoSmartErrors.Errors errors);

    void onFailure(MorphoSmartErrors.Errors errors);

    void onLocked(MorphoSmartErrors.Response response);

    void onMessages(MorphoSmartErrors.Messages messages);

    void onPermissionDenied(MorphoSmartErrors.Errors errors);

    void onPermissionGranted(MorphoSmartErrors.Response response);

    void onPermissionRequired(MorphoSmartErrors.Errors errors);

    void onQualityResponse(int i);

    void onRegistered(MorphoSmartErrors.Response response);

    void onResponse(byte[] bArr);

    void onUnlocked(MorphoSmartErrors.Response response);
}
