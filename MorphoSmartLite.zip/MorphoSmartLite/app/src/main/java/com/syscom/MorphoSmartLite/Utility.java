package com.syscom.MorphoSmartLite;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class Utility {
    Utility() {
    }

    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    public static String byteArrayToHexString(byte[] array) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : array) {
            int intVal = b & 255;
            if (intVal < 16) {
                hexString.append("0");
            }
            hexString.append(Integer.toHexString(intVal));
        }
        return hexString.toString();
    }

    public static byte[] decryptTemplate(byte[] cipherText, byte[] key) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        SecretKey secretKey = new SecretKeySpec(key, "DESede");
        IvParameterSpec iv = new IvParameterSpec(Arrays.copyOf(cipherText, 8));
        Cipher decipher = Cipher.getInstance("DESede/CBC/NoPadding");
        decipher.init(2, secretKey, iv);
        byte[] plainText = decipher.doFinal(Arrays.copyOfRange(cipherText, 8, cipherText.length));
//        System.out.println("Plain : "+Arrays.toString(plainText));
        return plainText;
    }

    public static byte[] encrypt(byte[] cipherText, byte[] key) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
        SecretKey secretKey = new SecretKeySpec(key, "DESede");
        IvParameterSpec iv = new IvParameterSpec(Arrays.copyOf(cipherText, 8));
        Cipher decipher = Cipher.getInstance("DESede/CBC/NoPadding");
        decipher.init(1, secretKey, iv);
        byte[] plainText = decipher.doFinal(Arrays.copyOfRange(cipherText, 8, cipherText.length));
        return plainText;
    }

    public static byte[] intToByteArray(int a) {
        byte[] ret = {(byte) ((a >> 24) & 255), (byte) ((a >> 16) & 255), (byte) ((a >> 8) & 255), (byte) (a & 255)};
        return ret;
    }

    public static String swapEndianness(String len) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i <= len.length() - 2; i += 2) {
            result.append((CharSequence) new StringBuilder(len.substring(i, i + 2)).reverse());
        }
        return result.reverse().toString();
    }

    public static String onesComplement(String length) {
        long valL = Long.parseLong(length, 16);
        String length2 = String.format("%08X", Long.valueOf(valL ^ (-1)));
        return length2.substring(length2.length() - 8, length2.length());
    }

    public static String convertHexToString(String hex) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hex.length() - 1; i += 2) {
            String output = hex.substring(i, i + 2);
            int decimal = hexStringToInt(output);
            sb.append((char) decimal);
        }
        return sb.toString();
    }

    public static int hexStringToInt(String value) {
        return Integer.parseInt(value, 16);}
}




